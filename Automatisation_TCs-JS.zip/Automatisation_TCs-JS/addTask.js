
const { Builder, By, Key, until } = require('selenium-webdriver')
const assert = require('assert')

describe('AddTask', function() {
  this.timeout(30000)
  let driver
  let vars
  beforeEach(async function() {
    driver = await new Builder().forBrowser('chrome').build()
    vars = {}
  })
  afterEach(async function() {
    await driver.quit();
  })
  it('AddTask', async function() {
    await driver.get("http://localhost:3000/")
    await driver.manage().window().setRect(1346, 708)
    await driver.findElement(By.css(".form-group:nth-child(1) > .form-control")).click()
    await driver.findElement(By.css(".form-group:nth-child(1) > .form-control")).sendKeys("test@test.com")
    await driver.findElement(By.css(".form-group:nth-child(2) > .form-control")).sendKeys("test")
    await driver.findElement(By.css(".btn")).click()
    await driver.findElement(By.css(".col:nth-child(1) > .form-control")).click()
    await driver.findElement(By.css(".col:nth-child(1) > .form-control")).sendKeys("Task One")
    await driver.findElement(By.css(".col:nth-child(2) > .form-control")).sendKeys("Description for task One")
    await driver.findElement(By.css(".btn")).click()
    {
      const element = await driver.findElement(By.css(".btn"))
      await driver.actions({ bridge: true }).moveToElement(element).perform()
    }
    {
      const element = await driver.findElement(By.CSS_SELECTOR, "body")
      await driver.actions({ bridge: true }).moveToElement(element, 0, 0).perform()
    }
    await driver.findElement(By.css(".list-group-item:nth-child(5)")).click()
    await driver.findElement(By.css(".list-group-item:nth-child(5) .badge")).click()
    await driver.findElement(By.css(".list-group-item:nth-child(5)")).click()
    await driver.findElement(By.css(".list-group-item:nth-child(5)")).click()
    {
      const element = await driver.findElement(By.css(".list-group-item:nth-child(5)"))
      await driver.actions({ bridge: true}).doubleClick(element).perform()
    }
    await driver.findElement(By.css(".list-group-item:nth-child(5)")).click()
  })
})
