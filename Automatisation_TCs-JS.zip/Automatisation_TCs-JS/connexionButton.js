
const { Builder, By, Key, until } = require('selenium-webdriver')
const assert = require('assert')

describe('ConnexionButton', function() {
  this.timeout(30000)
  let driver
  let vars
  beforeEach(async function() {
    driver = await new Builder().forBrowser('chrome').build()
    vars = {}
  })
  afterEach(async function() {
    await driver.quit();
  })
  it('ConnexionButton', async function() {
    await driver.get("http://localhost:3000/")
    await driver.manage().window().setRect(1346, 708)
    await driver.findElement(By.css(".btn")).click()
  })
})
