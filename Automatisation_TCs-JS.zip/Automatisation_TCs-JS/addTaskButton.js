
const { Builder, By, Key, until } = require('selenium-webdriver')
const assert = require('assert')

describe('AddTaskButton', function() {
  this.timeout(30000)
  let driver
  let vars
  beforeEach(async function() {
    driver = await new Builder().forBrowser('chrome').build()
    vars = {}
  })
  afterEach(async function() {
    await driver.quit();
  })
  it('AddTaskButton', async function() {
    await driver.get("http://localhost:3000/")
    await driver.manage().window().setRect(1346, 708)
    await driver.findElement(By.css(".form-group:nth-child(1) > .form-control")).click()
    await driver.findElement(By.css(".form-group:nth-child(1) > .form-control")).sendKeys("test@test.com")
    await driver.findElement(By.css(".form-group:nth-child(2) > .form-control")).sendKeys("test*")
    await driver.findElement(By.css(".form-group:nth-child(2) > .form-control")).sendKeys(Key.ENTER)
    await driver.findElement(By.css(".form-group:nth-child(2) > .form-control")).sendKeys("test")
    await driver.findElement(By.css(".form-group:nth-child(2) > .form-control")).sendKeys(Key.ENTER)
    await driver.findElement(By.css(".btn")).click()
    await driver.findElement(By.css(".btn")).click()
    await driver.findElement(By.css(".btn")).click()
    await driver.findElement(By.css("html")).click()
    await driver.findElement(By.css(".btn")).click()
  })
})
